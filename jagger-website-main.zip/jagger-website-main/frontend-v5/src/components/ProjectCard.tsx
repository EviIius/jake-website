import type { ProjectEntry } from "../types/content";
import CardDisclosure from "./CardDisclosure";
import { getLinkToneClass, inferChipTone, sortChipLabels } from "./pillTones";
import { renderInlineEmphasis } from "./renderInlineEmphasis";
import { resolveSiteHref, subdomainHref } from "../utils/siteUrls";
import {
  DomesIcon,
  GeneticIcon,
  JaggerScriptIcon,
  JolorIcon,
  JordleIcon,
  MaterializeIcon,
  OJamlIcon,
  RengineIcon,
  TsxLightIcon,
  TypingEffectIcon
} from "../features/games/GameIcons";

const documentedProjects = new Set([
  "ojaml",
  "liveboard",
  "hearth",
  "jaggerscript",
  "aixc-compressor",
  "genetic-ts",
  "rengine",
  "tsxlight-renderer"
]);

type ProjectCardProps = {
  project: ProjectEntry;
  id?: string;
};

function ProjectCard({ project, id }: ProjectCardProps) {
  const className = [
    "glass-card",
    "project-card",
    project.slug === "jagger-games" || project.slug === "portfolio-site"
      ? "project-card--wide"
      : null
  ].filter(Boolean).join(" ");

  const links = project.links.flatMap((link) =>
    link.label.toLowerCase() === "source" && documentedProjects.has(project.slug)
      ? [link, { label: "Docs", href: subdomainHref(import.meta.env.VITE_DOCS_URL, 5175, "https://docs.jaggerbrulato.com", `/${project.slug}`) }]
      : [link]
  );

  function getRelatedLinkClass(label: string) {
    return [
      "project-card__related-link",
      `project-card__related-link--${label.toLowerCase()}`
    ].join(" ");
  }

  function isPrimaryLink(label: string, href: string) {
    const normalized = label.toLowerCase();
    if (normalized.includes("npm")) {
      return true;
    }

    if (normalized.includes("source") || normalized.includes("reference")) {
      return false;
    }

    return (
      normalized.includes("open") ||
      normalized.includes("download") ||
      normalized.includes("play") ||
      normalized.includes("demo") ||
      normalized.includes("game") ||
      href.startsWith("/")
    );
  }

  function renderProjectIcon() {
    switch (project.icon) {
      case "domes":
        return <DomesIcon />;
      case "jordle":
        return <JordleIcon />;
      case "jolor":
        return <JolorIcon />;
      case "genetic":
        return <GeneticIcon />;
      case "jaggerscript":
        return <JaggerScriptIcon />;
      case "ojaml":
        return <OJamlIcon />;
      case "materialize":
        return <MaterializeIcon />;
      case "tsxlight":
        return <TsxLightIcon />;
      case "rengine":
        return <RengineIcon />;
      case "typing-effect":
        return <TypingEffectIcon />;
      default:
        return null;
    }
  }

  return (
    <article id={id} className={className}>
      {project.image ? (
        <img src={project.image} alt={`${project.title} preview`} className="project-card__image" />
      ) : (
        <div className={`project-card__image project-card__image--icon project-card__image--${project.icon ?? "default"}`} aria-hidden="true">
          <div className="project-card__icon-wrap">{renderProjectIcon()}</div>
        </div>
      )}
      <div className="project-card__content">
        <h3>{project.title}</h3>
        <p>{renderInlineEmphasis(project.description)}</p>
        {project.relatedLinks ? (
          <div className="project-card__related-links">
            {project.relatedLinks.map((link) => (
              <a
                key={link.href}
                href={resolveSiteHref(link.href)}
                className={getRelatedLinkClass(link.label)}
              >
                <strong>{link.label}</strong>
                <span>{link.description}</span>
              </a>
            ))}
          </div>
        ) : null}
        <CardDisclosure label={`${project.title} project details`}>
          <p className="project-card__impact">{renderInlineEmphasis(project.impact)}</p>
          <div className="chip-row">
            {sortChipLabels(project.stack).map((item) => (
              <span key={item} className={`chip chip--${inferChipTone(item)}`}>
                {item}
              </span>
            ))}
          </div>
        </CardDisclosure>
        <div className="project-card__links">
          {links.map((link) => {
            const resolvedHref = resolveSiteHref(link.href);
            return (
              <a
                key={link.href}
                href={resolvedHref}
                className={`project-card__link ${getLinkToneClass(
                  link.label === "Docs" ? "Source" : link.label,
                  link.href,
                  link.label === "Docs" ? false : isPrimaryLink(link.label, link.href)
                )}`}
                target={resolvedHref.startsWith("http") ? "_blank" : undefined}
                rel="noreferrer"
              >
                {link.label}
              </a>
            );
          })}
        </div>
      </div>
    </article>
  );
}

export default ProjectCard;
