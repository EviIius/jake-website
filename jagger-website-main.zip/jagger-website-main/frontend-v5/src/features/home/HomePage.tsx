import { useEffect, useLayoutEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import ExperienceCard from "../../components/ExperienceCard";
import MasonryGrid from "../../components/MasonryGrid";
import ProjectCard from "../../components/ProjectCard";
import { renderInlineEmphasis } from "../../components/renderInlineEmphasis";
import SectionShell from "../../components/SectionShell";
import SiteNavigation from "../../components/SiteNavigation";
import SkillClusterCard from "../../components/SkillClusterCard";
import { profileContent, headshotAsset } from "../../content/profile";
import { useMediaQuery } from "../../hooks/useMediaQuery";
import { usePrefersReducedMotion } from "../../hooks/usePrefersReducedMotion";
import { useSectionSpy } from "../../hooks/useSectionSpy";
import { usePageReveal } from "../../hooks/usePageReveal";
import ProfileLinkIcon from "./ProfileLinkIcon";
import SceneBackdrop from "./SceneBackdrop";
import { mainSiteHref, resolveSiteHref } from "../../utils/siteUrls";
import {
  getExperienceCardElementId,
  getProjectCardElementId,
  parseHomeHash
} from "./homeAnchors";

const sectionOrder = profileContent.sceneSections.map((section) => section.id);
const ENABLE_MOBILE_STATIC_SCENE = false;
const HEADER_SCROLL_GAP = 16;
const CARD_HASH_GAP = 14;
const INITIAL_SECTION_HASH_CORRECTION = 14;
const INITIAL_CARD_HASH_CORRECTION = 28;
const heroQuickLinkLabels = ["GitHub", "LinkedIn", "Resume", "Email"];
const heroQuickLinks = heroQuickLinkLabels
  .map((label) => profileContent.links.find((link) => link.label === label))
  .filter((link): link is (typeof profileContent.links)[number] => Boolean(link));
const wideProjectIndexes = profileContent.projects.flatMap((project, index) =>
  project.slug === "jagger-games" || project.slug === "portfolio-site" ? [index] : []
);

function isLocalHost(): boolean {
  if (import.meta.env.MODE === "test") return false;
  if (typeof window !== "undefined" && window.location) {
    const h = window.location.hostname;
    return h === "localhost" || h === "127.0.0.1" || h === "[::1]" || h === "0.0.0.0" || h.endsWith(".localhost");
  }
  return Boolean(import.meta.env.DEV);
}

function editorSiteHref() {
  const configured = (import.meta.env.VITE_EDITOR_URL as string | undefined)?.trim().replace(/\/+$/, "");
  if (configured) return configured;
  if (isLocalHost() || import.meta.env.DEV) {
    return `${window.location.protocol}//${window.location.hostname}:5182`;
  }

  return "https://editor.jaggerbrulato.com";
}

function designSiteHref() {
  const configured = (import.meta.env.VITE_DESIGN_URL as string | undefined)?.trim().replace(/\/+$/, "");
  if (configured) return configured;
  if (isLocalHost() || import.meta.env.DEV) {
    return `${window.location.protocol}//${window.location.hostname}:5183`;
  }

  return "https://design.jaggerbrulato.com";
}

function financeSiteHref() {
  const configured = (import.meta.env.VITE_FINANCE_URL as string | undefined)?.trim().replace(/\/+$/, "");
  if (configured) return configured;
  if (isLocalHost() || import.meta.env.DEV) {
    return `${window.location.protocol}//${window.location.hostname}:5184`;
  }

  return "https://finance.jaggerbrulato.com";
}

function HomePage() {
  const location = useLocation();
  const prefersReducedMotion = usePrefersReducedMotion();
  const isCompactViewport = useMediaQuery("(max-width: 768px)");
  const useStaticScene =
    prefersReducedMotion || (ENABLE_MOBILE_STATIC_SCENE && isCompactViewport);
  const activeSectionId = useSectionSpy(sectionOrder, profileContent.sceneSections[0].id);
  const isPageReady = usePageReveal();
  const hasSyncedSectionUrl = useRef(false);
  const initialHashPending = useRef(
    location.pathname === "/" && Boolean(location.hash || window.location.hash)
  );
  const activeSectionIndex = sectionOrder.indexOf(activeSectionId);
  const nextSectionId =
    activeSectionIndex >= 0 && activeSectionIndex < sectionOrder.length - 1
      ? sectionOrder[activeSectionIndex + 1]
      : "hero";
  const isAtLastSection = activeSectionIndex === sectionOrder.length - 1;

  function getHeaderScrollOffset() {
    const navShell = document.querySelector<HTMLElement>(".site-nav-shell");
    if (!navShell) {
      return HEADER_SCROLL_GAP;
    }

    return navShell.getBoundingClientRect().height + HEADER_SCROLL_GAP;
  }

  function scrollToSection(targetId: string) {
    if (targetId === "hero") {
      window.history.replaceState(null, "", "/#hero");
      window.scrollTo({ top: 0, behavior: prefersReducedMotion ? "auto" : "smooth" });
      return;
    }

    const element = document.getElementById(targetId);
    if (!element) {
      return;
    }

    window.history.replaceState(null, "", `/#${targetId}`);

    const top = Math.max(
      0,
      window.scrollY + element.getBoundingClientRect().top - getHeaderScrollOffset()
    );

    window.scrollTo({
      top,
      behavior: prefersReducedMotion ? "auto" : "smooth"
    });
  }

  function scrollToHashTarget(hash: string, options?: { initialLoad?: boolean }) {
    if (!hash) {
      return;
    }

    const parsedHash = parseHomeHash(hash);
    if (!parsedHash) {
      return;
    }

    const element = document.getElementById(parsedHash.targetElementId);
    if (!element) {
      return;
    }

    if (parsedHash.targetElementId === "hero") {
      window.scrollTo({ top: 0, behavior: prefersReducedMotion ? "auto" : "smooth" });
      return;
    }

    const initialCorrection = options?.initialLoad
      ? parsedHash.cardSlug
        ? INITIAL_CARD_HASH_CORRECTION
        : INITIAL_SECTION_HASH_CORRECTION
      : 0;
    const targetOffset =
      getHeaderScrollOffset() +
      (parsedHash.cardSlug ? CARD_HASH_GAP : 0) +
      initialCorrection;
    const top = Math.max(
      0,
      window.scrollY + element.getBoundingClientRect().top - targetOffset
    );

    window.scrollTo({
      top,
      behavior: prefersReducedMotion ? "auto" : "smooth"
    });
  }

  useLayoutEffect(() => {
    if (location.pathname === "/" && !location.hash) {
      window.scrollTo({ top: 0, behavior: "auto" });
    }
  }, [location.pathname, location.hash]);

  useLayoutEffect(() => {
    if (location.pathname !== "/") {
      initialHashPending.current = false;
      return;
    }

    const hash = location.hash || window.location.hash;
    if (!hash) {
      initialHashPending.current = false;
      return;
    }

    const isInitialLoad = initialHashPending.current;
    if (isInitialLoad && !isPageReady) {
      return;
    }

    initialHashPending.current = false;
    scrollToHashTarget(hash, { initialLoad: isInitialLoad });
  }, [isPageReady, location.hash, location.pathname, prefersReducedMotion]);

  useEffect(() => {
    if (location.pathname !== "/") {
      return;
    }

    const onHashChange = () => {
      initialHashPending.current = false;
      scrollToHashTarget(window.location.hash);
    };

    window.addEventListener("hashchange", onHashChange);

    return () => {
      window.removeEventListener("hashchange", onHashChange);
    };
  }, [location.pathname, prefersReducedMotion]);

  useEffect(() => {
    if (location.pathname !== "/") {
      hasSyncedSectionUrl.current = false;
      return;
    }

    if (!hasSyncedSectionUrl.current) {
      hasSyncedSectionUrl.current = true;
      return;
    }

    window.history.replaceState(null, "", `/#${activeSectionId}`);
  }, [activeSectionId, location.pathname]);

  return (
    <div className={isPageReady ? "page-shell page-shell--ready" : "page-shell page-shell--entering"}>
      <SceneBackdrop
        sections={profileContent.sceneSections}
        activeSectionId={activeSectionId}
        useStaticScene={useStaticScene}
      />
      <SiteNavigation brandHref="/"
        sections={profileContent.sceneSections}
        activeSectionId={activeSectionId}
        onSectionNavigate={scrollToSection}
      />

      <main className="content-shell home-shell">
        <section id="hero" className="hero-panel">
          <div className="hero-panel__copy">
            <div className="hero-panel__copy-content">
              <span className="hero-panel__eyebrow">{profileContent.sceneSections[0].eyebrow}</span>
              <h1>{profileContent.name}</h1>
              <p className="hero-panel__title">{renderInlineEmphasis(profileContent.title)}</p>
              <p className="hero-panel__summary">{renderInlineEmphasis(profileContent.heroSummary)}</p>
              <ul className="detail-list detail-list--hero">
                {profileContent.heroBullets.map((bullet) => (
                  <li key={bullet}>{renderInlineEmphasis(bullet)}</li>
                ))}
              </ul>
              <div className="hero-panel__view-links" aria-label="Alternate portfolio views">
                <a className="hero-panel__quick-link hero-panel__view-link" href={mainSiteHref("/")}>Main portfolio ↗</a>
                <a
                  className="hero-panel__quick-link hero-panel__view-link hero-panel__view-link--editor"
                  href={editorSiteHref()}
                >
                  <svg viewBox="0 0 18 18" aria-hidden="true" focusable="false">
                    <path
                      d="m7 4-4 5 4 5m4-10 4 5-4 5"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.7"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <span>Editor view</span>
                </a>
                <a
                  className="hero-panel__quick-link hero-panel__view-link hero-panel__view-link--design"
                  href={designSiteHref()}
                >
                  <svg viewBox="0 0 18 18" aria-hidden="true" focusable="false">
                    <path
                      d="M9 2.5a6.5 6.5 0 1 0 0 13h1.2a1.45 1.45 0 0 0 0-2.9h-.65a1.2 1.2 0 0 1 0-2.4H12A3.5 3.5 0 0 0 15.5 6.7C15.5 4.1 12.6 2.5 9 2.5Z"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinejoin="round"
                    />
                    <circle cx="5.8" cy="7.1" r=".8" fill="currentColor" />
                    <circle cx="8.2" cy="5.2" r=".8" fill="currentColor" />
                    <circle cx="11.2" cy="5.4" r=".8" fill="currentColor" />
                  </svg>
                  <span>Design view</span>
                </a>
                <a
                  className="hero-panel__quick-link hero-panel__view-link hero-panel__view-link--finance"
                  href={financeSiteHref()}
                >
                  <svg viewBox="0 0 18 18" aria-hidden="true" focusable="false">
                    <path d="M2.5 13.5 6.2 9.8l2.4 2.1 5.2-6" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M10.8 5.9h3v3" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  <span>Finance view</span>
                </a>
              </div>
              <div className="hero-panel__quick-links" aria-label="Profile links">
                {heroQuickLinks.map((link) => {
                  const resolved = resolveSiteHref(link.href);
                  return (
                    <a
                      key={link.href}
                      className="hero-panel__quick-link"
                      href={resolved}
                      target={resolved.startsWith("http") ? "_blank" : undefined}
                      rel={resolved.startsWith("http") ? "noreferrer" : undefined}
                    >
                      <ProfileLinkIcon label={link.label} />
                      <span>{link.label}</span>
                    </a>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="hero-panel__aside">
            <div className="hero-panel__portrait-wrap">
              <img src={headshotAsset} alt="Jagger Brulato portrait" className="hero-panel__portrait" />
            </div>
            <div className="metric-grid">
              {profileContent.metrics.map((metric) => (
                metric.label === "Start Here" ? (
                  <a key={metric.label} className="glass-card metric-card metric-card--interactive" href={mainSiteHref("/ojaml")}>
                    <span>{metric.label}</span>
                    <strong className="metric-card__link-value">
                      {metric.value}
                      <span aria-hidden="true" className="metric-card__link-indicator">
                        <svg viewBox="0 0 16 16" focusable="false">
                          <path
                            d="M5 11L11 5M6 5h5v5"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="1.8"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </span>
                    </strong>
                  </a>
                ) : (
                  <article key={metric.label} className="glass-card metric-card">
                    <span>{metric.label}</span>
                    <strong>{metric.value}</strong>
                  </article>
                )
              ))}
            </div>
          </div>
        </section>

        <SectionShell
          id="impact"
          eyebrow="Focus"
          title="I like work that crosses **product, backend, data, infrastructure, and developer tooling**."
          summary="For me that has meant **consumer apps, React and Three.js product surfaces, Node services, platform automation, data pipelines, mobile software, dashboards, and internal systems**."
        >
          <div className="impact-grid">
            <article className="glass-card feature-card">
              <h3>Work across the stack</h3>
              <p>
                {renderInlineEmphasis(
                  "I can work from the **user experience** through the **backend, data model, event flow, infrastructure, and runtime behavior**."
                )}
              </p>
            </article>
            <article className="glass-card feature-card">
              <h3>Use systems work in product work</h3>
              <p>
                {renderInlineEmphasis(
                  "Platform and data systems work has made me better at product engineering. I think carefully about boundaries, data flow, queues, observability, failure modes, and rollout paths."
                )}
              </p>
            </article>
            <article className="glass-card feature-card">
              <h3>Build things other engineers use</h3>
              <p>
                {renderInlineEmphasis(
                  "I like building tools, dashboards, APIs, deployment paths, Terraform workflows, CI/CD systems, and abstractions that other engineers use."
                )}
              </p>
            </article>
          </div>
        </SectionShell>

        <SectionShell
          id="experience"
          eyebrow="Experience"
          title="My experience spans **product, platform, data, mobile, infrastructure, and leadership**."
          summary="That includes AI-native construction tools, staff and senior startup work, Google data systems, AWS platform engineering, internal developer platforms, production apps, and team leadership."
        >
          <MasonryGrid className="experience-grid">
            {profileContent.experience.map((entry) => (
              <ExperienceCard
                key={`${entry.company}-${entry.role}`}
                id={getExperienceCardElementId(entry)}
                entry={entry}
              />
            ))}
          </MasonryGrid>
        </SectionShell>

        <SectionShell
          id="projects"
          eyebrow="Projects"
          title="The projects show how I build outside of work."
          summary="They’re practical and technical: languages, parsers, runtimes, WebAssembly, games, simulations, compression, renderers, libraries, and backend utilities."
        >
          <MasonryGrid className="project-grid" wideItemIndexes={wideProjectIndexes}>
            {profileContent.projects.map((project) => (
              <ProjectCard
                key={project.slug}
                id={getProjectCardElementId(project)}
                project={project}
              />
            ))}
          </MasonryGrid>
        </SectionShell>

        <SectionShell
          id="craft"
          eyebrow="How I work"
          title="I care about **clear systems**, practical architecture, and maintainable code."
          summary="I like code with clear boundaries, obvious ownership, useful tests, good observability, and tradeoffs the team can explain."
        >
          <div className="skill-grid">
            {profileContent.skillClusters.map((cluster) => (
              <SkillClusterCard key={cluster.title} cluster={cluster} />
            ))}
          </div>
        </SectionShell>

        <SectionShell
          id="leadership"
          eyebrow="Leadership"
          title="I lead by making the work clear and staying involved in the implementation."
          summary="I set direction, make tradeoffs, mentor engineers, organize execution, review code, and take implementation work myself."
        >
          <div className="leadership-principles">
            <div className="glass-card">
              <strong>Set a clear direction</strong>
              <p>
                Turn an ambiguous goal into a plan with clear priorities, ownership,
                milestones, technical decisions, and a path to delivery.
              </p>
            </div>
            <div className="glass-card">
              <strong>Lead from the work</strong>
              <p>
                Make architecture decisions with firsthand context, and take on difficult
                implementation work when the team needs it: APIs, data flow, platform code,
                UI state, or deployment logic.
              </p>
            </div>
            <div className="glass-card">
              <strong>Organize for momentum</strong>
              <p>
                Break work into parallel tracks, surface dependencies early, and keep
                communication direct across product, design, engineering, and operations.
              </p>
            </div>
            <div className="glass-card">
              <strong>Raise the whole team</strong>
              <p>
                Share context, review thoughtfully, and help engineers take ownership of
                larger parts of the system, from feature work to architecture and production support.
              </p>
            </div>
          </div>
        </SectionShell>

        <SectionShell
          id="contact"
          eyebrow="Contact"
          title="If you need a staff engineer who can lead and build, reach out."
        >
          <div className="contact-layout">
            <div className="glass-card contact-card__intro">
              <p>
                {renderInlineEmphasis(
                  "Email is the most direct way to reach me. I’m interested in **startups, product engineering, platform work, data-heavy systems, infrastructure-heavy teams, and staff roles where I still write code**."
                )}
              </p>
              <a className="contact-card__cta" href={`mailto:${profileContent.email}`}>
                <span className="contact-card__cta-eyebrow">Email me directly</span>
                <strong>{profileContent.email}</strong>
              </a>
            </div>
            <div className="glass-card contact-card__panel">
              <div className="contact-card__fit">
                <span className="contact-card__eyebrow">Strong fit</span>
                <strong>I’m usually a good fit for</strong>
                <ul>
                  <li>Ownership over a product, platform, system, or technical direction</li>
                  <li>Problems that cross frontend, backend, data, infrastructure, CI/CD, or operations</li>
                  <li>A team that values direct communication, high ownership, and hands-on leadership</li>
                </ul>
              </div>
              <div className="contact-card__actions">
                <a className="contact-card__action" href={`mailto:${profileContent.email}`}>
                  <ProfileLinkIcon label="Email" />
                  <span>Email</span>
                </a>
                {profileContent.links
                  .filter((link) => !link.href.startsWith("mailto:"))
                  .map((link) => {
                    const resolved = resolveSiteHref(link.href);
                    return (
                      <a
                        key={link.href}
                        href={resolved}
                        className="contact-card__action"
                        target={resolved.startsWith("http") ? "_blank" : undefined}
                        rel="noreferrer"
                      >
                        <ProfileLinkIcon label={link.label} />
                        <span>{link.label}</span>
                      </a>
                    );
                  })}
              </div>
            </div>
          </div>
        </SectionShell>
      </main>

      <button
        type="button"
        className={
          isAtLastSection
            ? "section-advance section-advance--return"
            : "section-advance"
        }
        aria-label={
          isAtLastSection
            ? "Return to top of page"
            : `Go to ${profileContent.sceneSections[activeSectionIndex + 1]?.label ?? "next section"}`
        }
        title={
          isAtLastSection
            ? "Back to top"
            : `Next: ${profileContent.sceneSections[activeSectionIndex + 1]?.label ?? "Next section"}`
        }
        onClick={() => scrollToSection(nextSectionId)}
      >
        <span className="section-advance__label" aria-hidden={!isAtLastSection}>
          Back to top
        </span>
        <span className="section-advance__icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" role="presentation">
            <path
              d="M12 6v12M12 18l-5-5M12 18l5-5"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </span>
      </button>
    </div>
  );
}

export default HomePage;
